<template>
  <div>
   <img src="../assets/404.png"/>
  </div>
</template>

<script>
export default {
  name: 'NotFound'
}
</script>

<style scoped>

</style>
